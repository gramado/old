
// config.h

#ifndef __CONFIG_H
#define __CONFIG_H    1

// see: wm.c
#define CONFIG_USE_TILE    1



#endif    


