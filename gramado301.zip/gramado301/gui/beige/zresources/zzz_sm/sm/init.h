
// rtl
#include <types.h>
#include <stdio.h>
#include <stddef.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

#include <unistd.h>

#include <rtl/gramado.h>



// #bugbug: 
// not defined here. see: crt0.
// Delete this thing

int main ( int argc, char *argv[] );

//
// End.
//


