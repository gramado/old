
// sys/file.h


#ifndef __SYS_FILE_H
#define __SYS_FILE_H

int flock (int fd, int operation); 



#endif  

//
// End.
//



