
// Locale.c

#include <stddef.h>


// #todo
char *setlocale (int category, const char *locale)
{
    return "en_US";
}


