
// Nelson Cole 2 font.
// #suspended.

#ifndef __NC2_FONT_H
#define __NC2_FONT_H    1

#define NC2_TODO    1

#endif

