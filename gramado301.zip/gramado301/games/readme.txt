

	game1/ and game2/ uses a non orthodox projection routines.
	It is just a test of new concepts.

	
