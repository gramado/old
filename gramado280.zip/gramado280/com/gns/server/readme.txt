	gns server-side.
