
#include "lin8x8.h"	

void fmain()
{
	
}



