
// This a client-side library for GNS, Gramado Network Server.


#include "gns_pack.h"


//
// defines
//


#define LIBGNS_VERSION_STRING  "0.1"


//
// prototypes
//


void gns_yield(void);


// hello
int __gns_hello_request (int fd);
int __gns_hello_response(int fd);
int gns_hello (int fd);















