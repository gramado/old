
/*
 * File: up.h 
 * 
 *    Uni-processor (UP) support.
 * 
 */


#ifndef ____UP_H
#define ____UP_H


// See:
// https://en.wikipedia.org/wiki/Uniprocessor_system
// ...



// Obs: 
// Não tem ponteiro. Apenas para UniProcessor.

struct ProcessorBlock_d UPProcessorBlock;    
  

#endif   


