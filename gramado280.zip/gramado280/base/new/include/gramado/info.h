
#ifndef ____INFO_H
#define  ____INFO_H

unsigned long info_get_boot_info ( int i );

#endif   



