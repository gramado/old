
// sysinit.c
// Nothing for now.

int sysinitdummyyyy1123;


