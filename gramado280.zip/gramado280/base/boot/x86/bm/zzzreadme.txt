
 Sobre o diret�rio \msm:
 ======================
 
 Mass Storage Manager - (MSM).

 Todo esse m�dulo tem como prop�sito principal dar suporte em 32bit ao gerenciamento 
 de m�dias de armazenamento no contexto do Boot Manager em Ring0.
 
 Na faze de inicializa��o � necess�rio o maior suporte � m�dias de armazenamento poss�vel.
 � esse o prop�sito desse m�dulo.
 
 Documento criado em 2016. (Fred Nora).
 