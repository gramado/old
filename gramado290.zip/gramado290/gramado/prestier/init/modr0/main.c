

// modulo em ring0. antigo window server.

int main( int argc, char **argv)
{
    //#todo
    //printf()

    while(1){}
    return 0;
}



