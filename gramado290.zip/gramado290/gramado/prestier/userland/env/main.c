 // $env

 // This is gonna show all the environment variables.
