
// TESTTEST.BIN  ... APLICATIVO DE TESTE PARA SER CARREGADO 
                    NO PROCESSO INIT.


Informa��es sobre o aplicativo IDLE.BIN:
=======================================

    Idle process.
   	P3 - Processos em ring3, User Mode.	

Atribui��es:	
    Por enquanto esse process�o d�o deve realizar tarefa nenhuma.
	
Obs:    
	Por enquando cada aplicativo tem um endere�o diferente na mem�ria virtual,
    mas todos eles ter�o o mesmo endere�o, s� que cada processo dever� seu pr�prio 
	diret�rio de p�ginas.
	
	vers�o 1.0, 2016.