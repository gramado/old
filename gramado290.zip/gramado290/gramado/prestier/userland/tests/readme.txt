

	Small commands used for testing the libc and the rtl.
