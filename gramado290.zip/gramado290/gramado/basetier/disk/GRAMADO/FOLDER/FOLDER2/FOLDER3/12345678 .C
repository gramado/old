12345678.C: This is a text file.




