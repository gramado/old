

/*BSD style*/
#define	__const		const		/* define reserved names to standard */
#define	__signed	signed
#define	__volatile	volatile