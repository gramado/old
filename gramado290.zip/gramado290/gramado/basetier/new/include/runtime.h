
#ifndef __RUNTIME_H
#define __RUNTIME_H  1

int init_runtime (void);
int Runtime_initialize(void);


#endif    


