
// logon.h

#ifndef __LOGON_H
#define __LOGON_H    1

int init_logon_manager (void);

#endif    

