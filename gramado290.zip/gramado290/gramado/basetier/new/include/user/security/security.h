
// security.h

#ifndef __SECURITY_H
#define __SECURITY_H    1


//
// == Security ==========================================
//

int current_usersession;
int current_room; 
int current_desktop; 

// #todo
// We need some security routines.
// Chching all the security components,
// just like, user session, rooms and desktops


#endif    






