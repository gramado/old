	// #todo
	// autoridade de input
	// gerenciando as permissoes para os
	// aplicativos usarem os recursos de input.
