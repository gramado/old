

   This is the server part for the virtual terminal support.

   Initialization routines needs to call this file to setup the virtual terminal functionalities.
   