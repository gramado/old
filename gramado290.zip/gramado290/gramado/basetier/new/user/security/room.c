

#include <kernel.h>


int roomdummmy;    





