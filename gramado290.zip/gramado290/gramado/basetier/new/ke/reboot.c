
#include <kernel.h>    


/*
void emergency_reboot(void);
void emergency_reboot(void)
{
    hal_reboot();
    die();
}
*/


