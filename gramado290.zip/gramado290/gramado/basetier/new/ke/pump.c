

#include <kernel.h>

// rotinas para atender as syscalls desse grupo.


/*
int block_write(int dev, long * pos, char * buf, int count);
int block_write(int dev, long * pos, char * buf, int count)
{
    return -1;
}
*/

/*
int block_read(int dev, unsigned long * pos, char * buf, int count);
int block_read(int dev, unsigned long * pos, char * buf, int count)
{
    return -1;
}
*/





