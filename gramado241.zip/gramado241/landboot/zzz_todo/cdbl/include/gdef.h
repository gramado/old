/*
 * gdef.h
 * 
 * Descri��o:
 *     Defini��es globais para o Boot Loader.
 *     Obs: Esse arquivo deve ficar no topo dos includes.
 *
 * Hist�rico:
 *     Vers�o 1.0, Oct 2016 - Created.
 */


int gdefTesting;

//+Objects.
//+Global structs.
//...


//
//End.
//

