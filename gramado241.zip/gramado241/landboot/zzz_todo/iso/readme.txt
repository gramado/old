

x86/boot/iso

   Criando uma imagem iso para o sistema Gramado.