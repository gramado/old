
void r_refresh_screen (void);





