/*
 * File: bli386.h
 *     Boot Loader i386 especific support.
 *
 * sep 2016 - Created.
 */
 

int bliTesting; 
 
//
//End.
//

