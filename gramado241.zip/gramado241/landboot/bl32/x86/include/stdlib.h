

#ifndef __STDLIB_H
#define __STDLIB_H    1

void *malloc (size_t size);
void free (void *ptr);

#endif    



