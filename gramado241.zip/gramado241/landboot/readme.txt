

   prek -  pre-kernel environment.
