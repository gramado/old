=Small Lisp Implementation

==Build

    make

To run the basic test files:

    make tests


