# gramnt

	gramnt - Gramado New Technologies

	========================================================
	init:
	The init process.
	It's a ring3 process used to initialize the system.

	========================================================
	kernel:
	The base kernel.

