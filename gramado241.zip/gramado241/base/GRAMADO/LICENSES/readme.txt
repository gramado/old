Aqui ficar�o as licen�as para componentes diversos do sistema.
A licen�a principal ficar� em /gramado.