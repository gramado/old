
unsigned long test_unsignedlong1;

int test_var1;
int test_var2;
int test_var3;

int test_function ( int x, int y ){
	
	 	
	
    //return function1();
    //test_label_inside:
	
    //return (1111 + 2222);
	
	return  functionfake(); 
};

