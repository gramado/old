
static int var1;

static int main1(){
    
	// comment 
    /* comment again */
	//#ignore-directives-for-now

    return 0x4321;
};

