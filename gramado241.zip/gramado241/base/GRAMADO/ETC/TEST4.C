int main1(){

    asm (" mov ecx, 0x1234 ");
    return 0x4321;
};


