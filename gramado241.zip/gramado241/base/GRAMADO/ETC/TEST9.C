


/* on cc500 The first thing defined must be main(). */
int main1();
int main()
{
  return main1();
}

int main1()
{	
    return 1+2;
}

