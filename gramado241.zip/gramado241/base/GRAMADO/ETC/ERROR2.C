int (){
	return 0x4321;
};
