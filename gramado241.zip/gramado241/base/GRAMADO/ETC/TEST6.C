

void main()
{
	
	
	//testando parse_expression
	
    //if ( 1 + 2 )
    //{};

    //if ( 3 - 4 )
    //{};

    //if ( 5 <= 6 )
	//{};

    //if ( 7 >= 8 )
    //{};

	//sizeof(int);
    if ( 1 + sizeof (int) ) 
    {};		

    //while ( 10 + 11 )
	//{};

	//while ( 12 - 13 )
	//{};

	//while ( 14 <= 33 )
	//{};

   // while ( 16 >= 17 )
    //{};

	//sizeof(int);
   //while ( 10 + sizeof(long) )
	//{};
		
};
