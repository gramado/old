
    libipc -  Library for inter-process communication.
