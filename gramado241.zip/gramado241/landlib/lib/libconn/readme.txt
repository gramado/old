

    biblioteca client-side para conexão padrão com servidores do 
    sistema gramado.
