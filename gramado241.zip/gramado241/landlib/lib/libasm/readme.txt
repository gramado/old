	
	It's a library to build applications in Assembly Language.
	The apps will run on 32bit, ring 3.

	We have some reusable resources in the folder _res/.

	Please, take a look at some other similar projects.

	2020 - Fred Nora
