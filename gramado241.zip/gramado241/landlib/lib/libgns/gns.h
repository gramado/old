	// This a client-side library for GNS, Gramado Network Server.


//
// defines
//


#define LIBGNS_VERSION_STRING  "0.1"


//
// prototypes
//


void gns_yield(void);



