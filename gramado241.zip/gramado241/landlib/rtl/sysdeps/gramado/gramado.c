
// #obs
// a syscall está em stubs/
// Aqui vamos criar outras interações com 
// elementes específicos do sistema gramado.


 
#include "gramado.h" 
 

