

 // implementing sysmacros.h
 
 

/* 
dev_t makedev(unsigned int maj, unsigned int min);
unsigned int major(dev_t dev);
unsigned int minor(dev_t dev);
*/





