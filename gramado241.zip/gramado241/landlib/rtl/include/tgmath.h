

//tgmath.h


// Funções matemáticas.


