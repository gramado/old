
// #bugbug
// This file is not using the 8.3 DOS standard.


// stdio_ext.h


// Solaris introduced routines to allow portable access to the internals
// of the FILE structure, and glibc also implemented these.
       
       
void __fpurge (FILE *stream);



//
// End.
//

