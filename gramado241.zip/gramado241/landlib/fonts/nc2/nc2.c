
#include "nc2.h"	

void fmain()
{
	
}



