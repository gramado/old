/*
 * File: gwm.h 
 *     Main header file for the gwm.
 *     It uses the libgws library.
 */

#define xxxNOTHINGFORNOW    1234



