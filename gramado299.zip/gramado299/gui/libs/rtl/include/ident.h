

//vyunix style
//char myname[] = "research 11/70";


char myname[] = "research 12/19";



