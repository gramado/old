#ifndef _TIMES_H
#define _TIMES_H



#ifndef _CLOCK_T
#define _CLOCK_T
typedef long clock_t;		/* unit for system accounting */
#endif





#endif /* _TIMES_H */


