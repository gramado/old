

	Graphics device library
	This is a interface for the devices found in the device drivers.

	The window server uses this library for the low level routines.


