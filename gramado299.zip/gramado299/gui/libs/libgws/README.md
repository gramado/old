
## gws - Client-side library for the Gramado Window Server.

    This is the client-side library linked statically
    agains the client applications.
    Here we have routines for making the requests to the server
    and getting the responses.
    #todo: Actually we can create a library only for the 
    connections and the low level routines found in this library.


    
