
// Suporte ao compilador usado para construir o shell.


#ifndef __COMPILER__
#define __COMPILER__

int dummycompiler;


#endif



