

#ifndef __GWS_CONFIG_H
#define __GWS_CONFIG_H    1


int config_use_transparency;
//int config_use_transparency;
// ...

#endif    



