
// http.h

// HTTP Methods

/*
#define  HTTP_METHOD_GET      1000
#define  HTTP_METHOD_POST     1001
#define  HTTP_METHOD_PUT      1002
#define  HTTP_METHOD_HEAD     1003
#define  HTTP_METHOD_DELETE   1004
#define  HTTP_METHOD_PATCH    1005
#define  HTTP_METHOD_OPTIONS  1006
*/



