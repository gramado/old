
// connect.h

#ifndef __CONNECT_H
#define __CONNECT_H    1


// Registering the window server.
int register_ws (void);

#endif

//
// End
//

