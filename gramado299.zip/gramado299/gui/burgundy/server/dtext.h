

int dummydtext; 



