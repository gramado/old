	gns client-side app
