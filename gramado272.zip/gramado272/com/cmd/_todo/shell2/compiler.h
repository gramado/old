
// Suporte ao compilador usado para construir o shell.


int dummycompiler;


