/*
 * File: main.c
 * 
 *     return TRUE;
 */


// rtl
#include <types.h>
#include <stdio.h>


int main ( int argc, char *argv[] )
{
    return (int) TRUE;
}


//
// End.
//


