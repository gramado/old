/*
 * Fle: main.c
 * 
 *     return FALSE
 */


// rtl
#include <types.h>
#include <stdio.h> 
#include <stdlib.h>


int main ( int argc, char *argv[] )
{
    return (int) FALSE;
}


//
// End.
//


