

    Gramado Cmd.

    Comandos feitos com a libc que rodarão no terminal virtual ou no console.
   pretendo que todos fiquem soltos, com apenas um arquivo cada.
   assim podemos compilar todos de uma vez só.
