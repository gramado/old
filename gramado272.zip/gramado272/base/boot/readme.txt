	About this folder:


	vd/
	The virtual disk where the system will be installed at.
	The MBR code.


	x86/bm/
	The startup code.
	It initializes the system call the os boot loader.

	x86/bl/
	The os boot loader.
	It loader the kernel image and beyond.
	The kernel base is found in the new/ folder.

	2021 - Fred Nora.
