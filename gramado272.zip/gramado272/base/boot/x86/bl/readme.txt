﻿
Informações sobre o Boot Loader:
===============================

    BL.BIN


 size:
     0x00009000 ~ 0x00020000  


 Info:
     +
     + O Boot Loader fica no sistema de arquivos fat16.
     + 32bit protected mode.
     + address 0x00009000
     + entry point em 0x00009200
     +


    endereço virtual = 0x00021000.

;
; fim.
;

