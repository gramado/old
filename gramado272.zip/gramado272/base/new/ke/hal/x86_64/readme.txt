

/head

   entry point para a arquitetura x86.
    
   Ficam a inicializa��o de sistema feita em assembly
 e tamb�m outras rotinas de baixo n�vel como handlers
 de interrup��o.

  � um conjunto padronizado de arquivos que formam o m�duo head.o
que � o m�dulo de entrada do kernel base.