

#include <kernel.h>


int usessiondummmy;    



