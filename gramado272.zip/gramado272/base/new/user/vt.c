

#include <kernel.h>


int fg_console;


/*
// init module.
int vt_init_module (void);
int vt_init_module (void)
{

    register int i=0;

    debug_print("vt_init_module:\n");

    // init list
    // #todo: Check this limit

    for (i=0; i<32; ++i)
    {
        vtList[i] = (unsigned long) 0;
    };

    // ...
    
    return 0;
}
*/



