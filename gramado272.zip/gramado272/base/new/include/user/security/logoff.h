
// logoff.h

#ifndef __LOGOFF_H
#define __LOGOFF_H    1

int init_logoff (int mode);
int register_logoff_process ( pid_t pid );

#endif    



