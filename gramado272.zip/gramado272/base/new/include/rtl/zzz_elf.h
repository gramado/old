/*	$OpenBSD: elf.h,v 1.1 2017/10/17 09:34:52 mpi Exp $	*/

/*
 * Public domain.
 */

#ifndef _ELF_H_
#define _ELF_H_

//Nothing for now
//#include <sys/exec_elf.h>

#endif /* _ELF_H_ */



