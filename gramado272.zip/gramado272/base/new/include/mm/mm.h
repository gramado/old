
// mm.h

#ifndef ____MM_H
#define ____MM_H    1

//
// Size support.
//

#define KB  (1024)
#define MB  (1024 * 1024)
#define GB  (1024 * 1024 * 1024)


// Aligns a value on a boundary.
//#define ALIGN(x, a)    (((x) + ((a) - 1)) & ~((a) - 1))



#endif    


