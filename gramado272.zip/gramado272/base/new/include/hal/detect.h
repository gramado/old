

#ifndef __DETECT_H
#define __DETECT_H    1


int hal_probe_cpu (void);    
int hal_probe_processor_type (void);


void get_cpu_intel_parameters (void);


#endif    



