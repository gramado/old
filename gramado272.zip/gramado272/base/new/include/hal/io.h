
// io.h

#ifndef ____IO_H
#define ____IO_H    1

int ioInit(void);
int io_ioctl ( int fd, unsigned long request, unsigned long arg );

#endif    


