
 /net

 pasta para f�cil acesso aso componentes de rede, tendo em vista 
 a import�ncia dessa parte do sistema.