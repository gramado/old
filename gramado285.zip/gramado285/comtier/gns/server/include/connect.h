

#ifndef __CONNECT_H
#define __CONNECT_H


// Registering the network server.
int register_ns (void);


#endif



//
// End.
//

  


