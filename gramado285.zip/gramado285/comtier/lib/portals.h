// This is a wrapper for libgws and some other possible libs.
// More: Entry point for applications and system information.


// Callint the window server. 
#include "libgws/gws.h"


//
// Application entry point prototype
//

//int portals_main (int argc, char *argv[]);

//
//  System information
//


//int portals_get_portals_directory( ?? buffer );
//int portals_get_system_directory( ?? buffer );

// ...

// Portals flags

//#define PF_GRAMADO 0x00000001    // Running on gramado kernel.
//#define PF_...
