# lib

	Ring 3 libraries.
	
	gramsock/
	Extends the unix-like socket standard functions.

	libasm/
	#todo: Basic ring3 Asssembly language library.
	
	libconn/
	#todo: Low level connection support.
	
	libgns/
	gnssrv client-side library.
	
	libgws/
	gwssrv client-side library.
	
	libio01/
	Ring 3 library to access the standard PC i/o ports.
	
	libipc/
	#todo: ipc routines.
	
	libvt/
	#todo: 
	Routines to help creating virtual terminals.
	Probably using the libgws protocol.
	
	#todo: 
	Create libinput/ to handle the input devices.
	
	
