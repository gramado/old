
//testing single line comment

/*+ testing multiple lines comment. 	
	+ testing return constant.
	+ testing spaces.*/

int main(){/*comment 2*/return 0x4321;};