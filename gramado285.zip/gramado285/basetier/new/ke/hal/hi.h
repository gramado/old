


//hi.h (Hal Internal) hotinas internas do hal.

