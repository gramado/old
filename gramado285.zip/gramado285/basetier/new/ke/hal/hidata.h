/*
 * File: hidata.h
 *
 * Descri��o:
 *     Hal Internal Data. 
 *     (Dados que devem ficar apenas dentro do m�dulo /hal.)
 *
 */
 
int hiTesting;


//
// End.
//

