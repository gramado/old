

#ifndef ____KEYBOARD_H
#define ____KEYBOARD_H    1


int scStatus;

void DeviceInterface_PS2Keyboard(void); 



#endif   




