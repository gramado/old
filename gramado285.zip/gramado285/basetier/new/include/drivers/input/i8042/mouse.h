

#ifndef ____MOUSE_H
#define ____MOUSE_H    1


int dummmmkdsfmsd;


#endif   

