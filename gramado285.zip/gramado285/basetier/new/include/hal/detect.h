
// detect.h

#ifndef __DETECT_H
#define __DETECT_H    1

int detect_IsQEMU(void);
int isQEMU(void);
int hal_probe_cpu(void);
int hal_probe_processor_type(void);

#endif    

