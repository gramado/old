/*
 * File: up.h 
 *    Uni-processor (UP) support.
 */

// See:
// https://en.wikipedia.org/wiki/Uniprocessor_system
// ...


#ifndef ____UP_H
#define ____UP_H    1

// Obs: 
// Não tem ponteiro. Apenas para UniProcessor.

struct ProcessorBlock_d  UPProcessorBlock;


#endif   


