// pc  - Processs Control.

// header de suporte ao módulo /pc


// esse módulo cuida do gerenciamento de processos.
// é responsãvel pelo controle do ipc do mm e do scheduler.

