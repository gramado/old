
#ifndef ____GRAMADO_LIMITS_H
#define ____GRAMADO_LIMITS_H    1

// gramado/limits.h


//#test
//#define NR_OPEN    32


#endif    



