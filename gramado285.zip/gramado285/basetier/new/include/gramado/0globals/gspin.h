
// todos os spinlock do kernelbase ficarão aqui.

#ifndef ____GSPIN_H
#define ____GSPIN_H 1


//generic.
int __spinlock_ipc;


//#test
//int __spinlock_get_scancode;
//...


#endif    



