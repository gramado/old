
// Strings for the boot loader in english language.

#define STRINGS_BANNER \
            "*************************************\n"  \
            "*         Gramado Boot Loader       *\n"  \
			"*                                   *\n"  \
			"*************************************\n"  \
			"\n"


#define STRINGS_WELCOME_MESSAGE \
            "\n"   \
            "BL.BIN: Starting Boot Loader..\n"  \
            "\n"


